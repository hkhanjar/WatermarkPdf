<!DOCTYPE html>
<html>
<head>
	<title>test</title>
</head>
<body>
 <h1>$data->text</h1>
</body>
</html>