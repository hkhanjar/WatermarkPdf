<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Fpdf\Fpdf;
//use Fpdf\Fpdf;
//use setasign\fpdi\FPDI;
//use setasign\FPDI;
use setasign\Fpdi\Fpdi;
use App\PDF;

//use Ajaxray\PHPWatermark\Watermark;
//use PDF;
//use watermark;

class PhotoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

   
   
    public function index()
    {
    

    $currentFile = "rr.pdf";

    $newFile = "test.pdf";
     $pdf = new PDF();
    $pagecount = $pdf->setSourceFile($currentFile);
   //$pdf->addPage();
    for($i = 1; $i <= $pagecount; $i++){
        $pdf->addPage();//<- moved from outside loop
        $tplidx = $pdf->importPage($i);
      //  dd($tplidx);
    //dd($pdf->importedPages[$tplidx]);
      // $pdf->useImportedPage($tplidx, 0, 0);
        $pdf->MultiCell(0,5,$tplidx,0,'J');
        // now write some text above the imported page
       /* $pdf->SetFont('Arial', 'I', 40);
        $pdf->SetTextColor(217,217,217);
        $pdf->SetXY(50, 135);
       
     //  $this->Rotate($pdf,10); 
        $pdf->Write(0, "test.test@test.com");
       // $pdf->SetXY(50, 20);
        $pdf->SetX(50);
     //  $this->Rotate($pdf,10);
      $pdf->setAlpha(0.3);
          //  $this->_rotate(45, 100, 100); 
        $pdf->Write(30, "09988663365");
        //$this->Rotate(0); */
          
    }
   /* $txt="FPDF is a PHP class which allows to generate PDF files with pure PHP, that is to say ".
    "without using the PDFlib library. F from FPDF stands for Free: you may use it for any ".
    "kind of usage and modify it to suit your needs.\n\n";
    $pdf->SetFont('Arial', 'I', 12);
    $pdf->SetTextColor(0,0,0);
for($i=0;$i<25;$i++) 
    $pdf->Write(10*$i, $txt);
   /* $pdf->MultiCell(0,5,$txt,0,'J');
*/
    $pdf->Output($newFile, 'F');



    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
