<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Response;
use Fpdf\Fpdf;
use setasign\Fpdi\Fpdi;
use File;
use Illuminate\Support\Facades\Storage;

class PdfController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function PlaceWatermark($file, $text, $xxx, $yyy, $op, $outdir) {

        $name = uniqid();
        $font_size = 40;
        $ts=explode("\n",$text);
        $width=0;
        foreach ($ts as $k=>$string) {
            $width=max($width,strlen($string));
        }
        $width  = imagefontwidth($font_size)*$width*5;
        $height = imagefontheight($font_size)*count($ts)*5;
        $el=imagefontheight($font_size);
        $em=imagefontwidth($font_size);
        $img = imagecreatetruecolor($width,$height);
    // Background color
        $bg = imagecolorallocate($img, 255, 255, 255);
        imagefilledrectangle($img, 0, 0,$width ,$height , $bg);
    // Font color
        $color = imagecolorallocate($img, 255,100,100);
        foreach ($ts as $k=>$string) {
            $len = strlen($string);
            $ypos = 0;
            for($i=0;$i<$len;$i++){
                $xpos = $i * $em;
                $ypos = $k * $el;
                imagechar($img, $font_size, $xpos, $ypos, $string, $color);
                $string = substr($string, 1);      
            }
        }
        imagecolortransparent($img, $bg);
        $blank = imagecreatetruecolor($width, $height);
        $tbg = imagecolorallocate($blank, 255, 255, 255);
        imagefilledrectangle($blank, 0, 0,$width ,$height , $tbg);
        imagecolortransparent($blank, $tbg);
        if ( ($op < 0) OR ($op >100) ){
            $op = 100;
        }
        imagecopymerge($blank, $img, 0, 0, 0, 0, $width, $height, $op);
        imagepng($blank,$name.".png");
    // Created Watermark Image
        $pdf = new FPDI();

        if (file_exists($file)){
            $pagecount = $pdf->setSourceFile($file);
        } else {
            return FALSE;
        }
        for($i = 1; $i <= $pagecount; $i++){

            $pdf->addPage();
            $pdf->Image($name.'.png', $xxx, $yyy, 500, 150, 'png');

            $tplidx = $pdf->importPage($i);

            $pdf->useTemplate($tplidx, 0,0);

        }
        if ($outdir === TRUE){
       // $destinationPath = 'your_path';
            if(file_exists('test.pdf'))
                File::delete('test.pdf');
            $pdf->Output('test.pdf', 'F');

            $file="test.pdf";

            return response()->file('test.pdf', [
              'Content-Disposition' => 'inline; filename="'. "test.pdf" .'"'
          ]);
        } else {
            return $pdf;
        }
    }


    public function index(Request $request)
    {

    $file= $request->file('pdfFile')->getPathName();

      $this->PlaceWatermark( $file, "test.testttt@test.com\n 09669605574", 50, 120, 40,TRUE);



  }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
